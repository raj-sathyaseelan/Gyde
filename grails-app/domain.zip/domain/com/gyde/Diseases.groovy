package com.gyde

class Diseases {
	String diseaseName 
}
