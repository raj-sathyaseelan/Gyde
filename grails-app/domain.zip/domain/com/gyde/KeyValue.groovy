package com.gyde

class KeyValue {
	
	String keyID
	String value
	
}
